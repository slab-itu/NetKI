from helper import helper
import numpy as np
from sklearn.utils import shuffle
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import cross_val_score
obj = helper()
obj.create_env()
dataset="proteins_full"
#load dataset online
# graphs,adj_list, labels,attr = obj.return_dataset(dataset)
#load dataset from file
graphs, labels = obj.load_data(dataset)
print("total graphs in the dataset:",len(graphs))
scores,max_val = obj.GenerateAllApproxEmb(graphs)
scaled_data, max_val = obj.remove_outliers(scores)
emb = obj.generateHistogram(scaled_data, max_val,500)
print("Applying the classifier")
feature_matrix,labels = shuffle(emb,labels)
model = RandomForestClassifier(n_estimators=200)
res = cross_val_score(model, feature_matrix, labels, cv=10, scoring='accuracy')
print("10 fold cross validatiaon accuracy on:",np.mean(res))
